package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.MainViewModel
import com.example.ui.calculator.CalculatorScreen
import com.example.ui.converter.ConverterScreen
import com.example.ui.editor.ImageEditorScreen
import com.example.ui.history.HistoryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.pdf.PdfCreatorScreen
import com.example.ui.saved.SavedDocumentsScreen
import com.example.ui.scanner.ScannerScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.NubToWordBDTTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val appSettings by viewModel.appSettings.collectAsState()
            val isDarkTheme = when (appSettings.theme) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }

            NubToWordBDTTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding()
                ) {
                    AppNavigation(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                viewModel = viewModel,
                onNavigate = { route -> navController.navigate(route) }
            )
        }

        composable("converter") {
            ConverterScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToHistory = { navController.navigate("history") }
            )
        }

        composable("scanner") {
            ScannerScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToPdf = { path ->
                    navController.navigate("pdf?path=${path ?: ""}")
                }
            )
        }

        composable(
            route = "pdf?path={path}",
            arguments = listOf(navArgument("path") {
                type = NavType.StringType
                defaultValue = ""
            })
        ) { backStackEntry ->
            val path = backStackEntry.arguments?.getString("path")?.ifEmpty { null }
            PdfCreatorScreen(
                viewModel = viewModel,
                initialPdfPath = path,
                onBack = { navController.popBackStack() }
            )
        }

        composable("editor") {
            ImageEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("calculator") {
            CalculatorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("saved") {
            SavedDocumentsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("history") {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
