package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // Conversion History
    @Query("SELECT * FROM conversion_history ORDER BY timestamp DESC")
    fun getAllConversions(): Flow<List<ConversionRecord>>

    @Query("SELECT * FROM conversion_history ORDER BY timestamp DESC LIMIT 5")
    fun getRecentConversions(): Flow<List<ConversionRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversion(record: ConversionRecord): Long

    @Delete
    suspend fun deleteConversion(record: ConversionRecord)

    @Query("DELETE FROM conversion_history")
    suspend fun clearAllConversions()

    // Saved Documents
    @Query("SELECT * FROM saved_documents ORDER BY updatedAt DESC")
    fun getAllDocuments(): Flow<List<DocumentRecord>>

    @Query("SELECT * FROM saved_documents ORDER BY updatedAt DESC LIMIT 5")
    fun getRecentDocuments(): Flow<List<DocumentRecord>>

    @Query("SELECT * FROM saved_documents WHERE title LIKE '%' || :query || '%' ORDER BY updatedAt DESC")
    fun searchDocuments(query: String): Flow<List<DocumentRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: DocumentRecord): Long

    @Update
    suspend fun updateDocument(document: DocumentRecord)

    @Delete
    suspend fun deleteDocument(document: DocumentRecord)

    @Query("DELETE FROM saved_documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Long)

    // Calculator History
    @Query("SELECT * FROM calculator_history ORDER BY timestamp DESC LIMIT 30")
    fun getCalculatorHistory(): Flow<List<CalculatorRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalculatorRecord(record: CalculatorRecord): Long

    @Query("DELETE FROM calculator_history")
    suspend fun clearCalculatorHistory()
}
