package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversion_history")
data class ConversionRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val rawInput: String,
    val formattedAmount: String,
    val wordsEnglish: String,
    val wordsBangla: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
