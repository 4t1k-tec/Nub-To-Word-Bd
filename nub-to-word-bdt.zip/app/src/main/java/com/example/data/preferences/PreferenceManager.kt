package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "app_preferences")

data class AppSettings(
    val language: String = "en", // "en" or "bn"
    val theme: String = "system", // "system", "light", "dark"
    val hapticEnabled: Boolean = true,
    val defaultPdfSize: String = "A4",
    val defaultFilter: String = "CLARITY",
    val includePoishaWords: Boolean = true,
    val takaOnlySuffix: Boolean = true
)

class PreferenceManager(private val context: Context) {

    companion object {
        val KEY_LANGUAGE = stringPreferencesKey("key_language")
        val KEY_THEME = stringPreferencesKey("key_theme")
        val KEY_HAPTIC = booleanPreferencesKey("key_haptic")
        val KEY_DEFAULT_PDF_SIZE = stringPreferencesKey("key_default_pdf_size")
        val KEY_DEFAULT_FILTER = stringPreferencesKey("key_default_filter")
        val KEY_INCLUDE_POISHA = booleanPreferencesKey("key_include_poisha")
        val KEY_TAKA_ONLY_SUFFIX = booleanPreferencesKey("key_taka_only_suffix")
    }

    val appSettingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            language = prefs[KEY_LANGUAGE] ?: "en",
            theme = prefs[KEY_THEME] ?: "system",
            hapticEnabled = prefs[KEY_HAPTIC] ?: true,
            defaultPdfSize = prefs[KEY_DEFAULT_PDF_SIZE] ?: "A4",
            defaultFilter = prefs[KEY_DEFAULT_FILTER] ?: "CLARITY",
            includePoishaWords = prefs[KEY_INCLUDE_POISHA] ?: true,
            takaOnlySuffix = prefs[KEY_TAKA_ONLY_SUFFIX] ?: true
        )
    }

    suspend fun setLanguage(lang: String) {
        context.dataStore.edit { it[KEY_LANGUAGE] = lang }
    }

    suspend fun setTheme(theme: String) {
        context.dataStore.edit { it[KEY_THEME] = theme }
    }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_HAPTIC] = enabled }
    }

    suspend fun setDefaultPdfSize(size: String) {
        context.dataStore.edit { it[KEY_DEFAULT_PDF_SIZE] = size }
    }

    suspend fun setDefaultFilter(filter: String) {
        context.dataStore.edit { it[KEY_DEFAULT_FILTER] = filter }
    }

    suspend fun setIncludePoishaWords(include: Boolean) {
        context.dataStore.edit { it[KEY_INCLUDE_POISHA] = include }
    }

    suspend fun setTakaOnlySuffix(suffix: Boolean) {
        context.dataStore.edit { it[KEY_TAKA_ONLY_SUFFIX] = suffix }
    }
}
