package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.CalculatorRecord
import com.example.data.db.ConversionRecord
import com.example.data.db.DocumentRecord
import com.example.data.preferences.AppSettings
import com.example.data.preferences.PreferenceManager
import com.example.ui.calculator.CalculatorEngine
import com.example.util.BdtNumberToWordsConverter
import com.example.util.BdtTimeHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.appDao()
    private val prefManager = PreferenceManager(application)

    // Preferences state
    val appSettings: StateFlow<AppSettings> = prefManager.appSettingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    // Live Bangladesh Time
    private val _liveTime = MutableStateFlow(BdtTimeHelper.getCurrentBdtDateTime())
    val liveTime: StateFlow<BdtTimeHelper.FormattedDateTime> = _liveTime.asStateFlow()

    // Home / Converter Quick Conversion State
    private val _currentInput = MutableStateFlow("12345678")
    val currentInput: StateFlow<String> = _currentInput.asStateFlow()

    private val _conversionResult = MutableStateFlow(
        BdtNumberToWordsConverter.convert("12345678")
    )
    val conversionResult: StateFlow<BdtNumberToWordsConverter.ConversionResult> = _conversionResult.asStateFlow()

    // Database Flows
    val recentDocuments: StateFlow<List<DocumentRecord>> = dao.getRecentDocuments().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allDocuments: StateFlow<List<DocumentRecord>> = dao.getAllDocuments().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentConversions: StateFlow<List<ConversionRecord>> = dao.getRecentConversions().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allConversions: StateFlow<List<ConversionRecord>> = dao.getAllConversions().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val calculatorHistory: StateFlow<List<CalculatorRecord>> = dao.getCalculatorHistory().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        // Start live Bangladesh clock ticker
        viewModelScope.launch {
            while (true) {
                _liveTime.value = BdtTimeHelper.getCurrentBdtDateTime()
                delay(1000L)
            }
        }
    }

    fun updateInput(input: String) {
        _currentInput.value = input
        val settings = appSettings.value
        _conversionResult.value = BdtNumberToWordsConverter.convert(
            input = input,
            includePoishaWords = settings.includePoishaWords,
            takaOnlySuffix = settings.takaOnlySuffix
        )
    }

    fun saveCurrentConversion() {
        val result = _conversionResult.value
        if (result.isValid && result.formattedAmount.isNotEmpty()) {
            viewModelScope.launch {
                dao.insertConversion(
                    ConversionRecord(
                        rawInput = result.rawInput,
                        formattedAmount = result.formattedAmount,
                        wordsEnglish = result.englishWords,
                        wordsBangla = result.banglaWords
                    )
                )
            }
        }
    }

    fun deleteConversion(record: ConversionRecord) {
        viewModelScope.launch {
            dao.deleteConversion(record)
        }
    }

    fun clearAllConversions() {
        viewModelScope.launch {
            dao.clearAllConversions()
        }
    }

    fun registerCreatedDocument(file: File, mimeType: String, pageCount: Int) {
        viewModelScope.launch {
            dao.insertDocument(
                DocumentRecord(
                    title = file.name,
                    filePath = file.absolutePath,
                    mimeType = mimeType,
                    pageCount = pageCount,
                    fileSize = file.length()
                )
            )
        }
    }

    fun deleteDocument(record: DocumentRecord) {
        viewModelScope.launch {
            dao.deleteDocument(record)
            try {
                val f = File(record.filePath)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
    }

    fun renameDocument(record: DocumentRecord, newTitle: String) {
        val cleanTitle = if (record.mimeType == "application/pdf" && !newTitle.endsWith(".pdf", ignoreCase = true)) {
            "$newTitle.pdf"
        } else {
            newTitle
        }
        viewModelScope.launch {
            dao.updateDocument(
                record.copy(title = cleanTitle, updatedAt = System.currentTimeMillis())
            )
        }
    }

    fun saveCalculation(expression: String, result: String) {
        viewModelScope.launch {
            dao.insertCalculatorRecord(
                CalculatorRecord(
                    expression = expression,
                    result = result
                )
            )
        }
    }

    fun clearCalculatorHistory() {
        viewModelScope.launch {
            dao.clearCalculatorHistory()
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            prefManager.setLanguage(lang)
        }
    }

    fun setTheme(theme: String) {
        viewModelScope.launch {
            prefManager.setTheme(theme)
        }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefManager.setHapticEnabled(enabled)
        }
    }

    fun setTakaOnlySuffix(suffix: Boolean) {
        viewModelScope.launch {
            prefManager.setTakaOnlySuffix(suffix)
            updateInput(_currentInput.value)
        }
    }

    fun setIncludePoishaWords(include: Boolean) {
        viewModelScope.launch {
            prefManager.setIncludePoishaWords(include)
            updateInput(_currentInput.value)
        }
    }
}
