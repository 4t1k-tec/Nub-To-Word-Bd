package com.example.ui.calculator

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*

object CalculatorEngine {

    var isDegreeMode: Boolean = true

    /**
     * Evaluates a mathematical expression string and returns the formatted result.
     */
    fun evaluate(expression: String): Result<String> {
        try {
            val sanitized = expression
                .replace("×", "*")
                .replace("÷", "/")
                .replace("π", Math.PI.toString())
                .replace("e", Math.E.toString())

            val tokens = tokenize(sanitized)
            val postfix = infixToPostfix(tokens)
            val result = evaluatePostfix(postfix)

            if (result.isNaN() || result.isInfinite()) {
                return Result.failure(ArithmeticException("Error: Division by zero or invalid input"))
            }

            // Format result cleanly (strip trailing zeroes if integer)
            val bd = BigDecimal(result).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros()
            val formatted = bd.toPlainString()
            return Result.success(formatted)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        while (i < expr.length) {
            val c = expr[i]
            when {
                c.isWhitespace() -> i++
                c in "+-*/^()%" -> {
                    // Check for unary minus: if '-' is preceded by '(' or operator or at start
                    if (c == '-' && (tokens.isEmpty() || tokens.last() in listOf("+", "-", "*", "/", "^", "("))) {
                        // Unary minus: peek ahead for number
                        var numStr = "-"
                        i++
                        while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                            numStr += expr[i]
                            i++
                        }
                        tokens.add(numStr)
                    } else {
                        tokens.add(c.toString())
                        i++
                    }
                }
                c.isLetter() -> {
                    // function name like sin, cos, tan, log, ln, sqrt
                    val sb = StringBuilder()
                    while (i < expr.length && expr[i].isLetter()) {
                        sb.append(expr[i])
                        i++
                    }
                    tokens.add(sb.toString())
                }
                c.isDigit() || c == '.' -> {
                    val sb = StringBuilder()
                    while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                        sb.append(expr[i])
                        i++
                    }
                    tokens.add(sb.toString())
                }
                else -> i++
            }
        }
        return tokens
    }

    private fun precedence(op: String): Int = when (op) {
        "+", "-" -> 1
        "*", "/", "%" -> 2
        "^" -> 3
        "sin", "cos", "tan", "log", "ln", "sqrt" -> 4
        else -> 0
    }

    private fun infixToPostfix(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = ArrayDeque<String>()

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> output.add(token)
                token in listOf("sin", "cos", "tan", "log", "ln", "sqrt") -> stack.addFirst(token)
                token == "(" -> stack.addFirst(token)
                token == ")" -> {
                    while (stack.isNotEmpty() && stack.first() != "(") {
                        output.add(stack.removeFirst())
                    }
                    if (stack.isNotEmpty() && stack.first() == "(") {
                        stack.removeFirst()
                    }
                    if (stack.isNotEmpty() && stack.first() in listOf("sin", "cos", "tan", "log", "ln", "sqrt")) {
                        output.add(stack.removeFirst())
                    }
                }
                else -> { // Operator
                    while (stack.isNotEmpty() && precedence(stack.first()) >= precedence(token)) {
                        output.add(stack.removeFirst())
                    }
                    stack.addFirst(token)
                }
            }
        }
        while (stack.isNotEmpty()) {
            output.add(stack.removeFirst())
        }
        return output
    }

    private fun evaluatePostfix(postfix: List<String>): Double {
        val stack = ArrayDeque<Double>()
        for (token in postfix) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                stack.addFirst(num)
            } else if (token in listOf("sin", "cos", "tan", "log", "ln", "sqrt")) {
                if (stack.isEmpty()) throw IllegalArgumentException("Missing operand")
                val a = stack.removeFirst()
                val res = when (token) {
                    "sin" -> sin(if (isDegreeMode) Math.toRadians(a) else a)
                    "cos" -> cos(if (isDegreeMode) Math.toRadians(a) else a)
                    "tan" -> tan(if (isDegreeMode) Math.toRadians(a) else a)
                    "log" -> log10(a)
                    "ln" -> ln(a)
                    "sqrt" -> {
                        if (a < 0) throw ArithmeticException("Negative sqrt")
                        sqrt(a)
                    }
                    else -> 0.0
                }
                stack.addFirst(res)
            } else {
                if (stack.size < 2) throw IllegalArgumentException("Invalid syntax")
                val b = stack.removeFirst()
                val a = stack.removeFirst()
                val res = when (token) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> {
                        if (b == 0.0) throw ArithmeticException("Division by zero")
                        a / b
                    }
                    "%" -> a % b
                    "^" -> a.pow(b)
                    else -> throw IllegalArgumentException("Unknown operator $token")
                }
                stack.addFirst(res)
            }
        }
        if (stack.size != 1) throw IllegalArgumentException("Invalid syntax")
        return stack.first()
    }
}
