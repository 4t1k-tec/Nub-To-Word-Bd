package com.example.ui.calculator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.NothingCard
import com.example.ui.theme.NothingRed
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.util.HapticHelper
import com.example.util.ShareHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val appSettings by viewModel.appSettings.collectAsState()
    val isBangla = appSettings.language == "bn"
    val hapticEnabled = appSettings.hapticEnabled

    var expression by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("0") }
    var isDegreeMode by remember { mutableStateOf(true) }
    var showScientific by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }

    val calcHistory by viewModel.calculatorHistory.collectAsState()

    fun onKeyClick(key: String) {
        HapticHelper.performClick(context, hapticEnabled)
        when (key) {
            "AC" -> {
                expression = ""
                resultText = "0"
            }
            "DEL" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                }
            }
            "=" -> {
                if (expression.isNotEmpty()) {
                    HapticHelper.performHeavyClick(context, hapticEnabled)
                    CalculatorEngine.isDegreeMode = isDegreeMode
                    val evalResult = CalculatorEngine.evaluate(expression)
                    if (evalResult.isSuccess) {
                        resultText = evalResult.getOrNull() ?: "0"
                        viewModel.saveCalculation(expression, resultText)
                    } else {
                        resultText = "Error"
                    }
                }
            }
            "+/-" -> {
                if (expression.startsWith("-")) {
                    expression = expression.substring(1)
                } else if (expression.isNotEmpty()) {
                    expression = "-$expression"
                }
            }
            "x²" -> expression += "^2"
            "x^y" -> expression += "^"
            "√" -> expression += "sqrt("
            "1/x" -> expression = "1/($expression)"
            "sin" -> expression += "sin("
            "cos" -> expression += "cos("
            "tan" -> expression += "tan("
            "log" -> expression += "log("
            "ln" -> expression += "ln("
            "π" -> expression += "π"
            "e" -> expression += "e"
            else -> {
                expression += key
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(NothingRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBangla) "ক্যাসিও ক্যালকুলেটর" else "CASIO-STYLE CALCULATOR",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            HapticHelper.performClick(context, hapticEnabled)
                            onBack()
                        },
                        modifier = Modifier.testTag("calc_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            HapticHelper.performClick(context, hapticEnabled)
                            showHistorySheet = true
                        },
                        modifier = Modifier.testTag("calc_history_btn")
                    ) {
                        Icon(Icons.Default.History, contentDescription = "History")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // High-Contrast Casio LCD Style Display
            NothingCard(hasRedDot = true) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    // Header indicators (DEG/RAD, Sci toggle, Copy)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    isDegreeMode = !isDegreeMode
                                },
                                shape = RoundedCornerShape(4.dp),
                                color = if (isDegreeMode) NothingRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = if (isDegreeMode) "DEG" else "RAD",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDegreeMode) NothingRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Surface(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    showScientific = !showScientific
                                },
                                shape = RoundedCornerShape(4.dp),
                                color = if (showScientific) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "fx",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (showScientific) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                HapticHelper.performClick(context, hapticEnabled)
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Calc Result", resultText))
                                Toast.makeText(context, "Result copied", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Expression input line
                    Text(
                        text = expression.ifEmpty { "0" },
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = SpaceGroteskFontFamily,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        textAlign = TextAlign.End
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Main Result Display
                    Text(
                        text = resultText,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        fontFamily = SpaceGroteskFontFamily,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        textAlign = TextAlign.End
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Scientific Functions Panel (Toggled or shown above keypad)
            AnimatedVisibility(visible = showScientific) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                ) {
                    val sciRow1 = listOf("sin", "cos", "tan", "log", "ln")
                    val sciRow2 = listOf("√", "x²", "x^y", "1/x", "π")

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sciRow1.forEach { key ->
                            CalcKey(
                                label = key,
                                modifier = Modifier.weight(1f).height(40.dp),
                                isAccent = false,
                                isSpecial = true,
                                onClick = { onKeyClick(key) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sciRow2.forEach { key ->
                            CalcKey(
                                label = key,
                                modifier = Modifier.weight(1f).height(40.dp),
                                isAccent = false,
                                isSpecial = true,
                                onClick = { onKeyClick(key) }
                            )
                        }
                    }
                }
            }

            // Standard Casio Keypad Matrix
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val grid = listOf(
                    listOf("AC", "(", ")", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "-"),
                    listOf("1", "2", "3", "+"),
                    listOf("+/-", "0", ".", "=")
                )

                grid.forEach { rowKeys ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowKeys.forEach { key ->
                            val isRedEqual = key == "="
                            val isAction = key in listOf("AC", "÷", "×", "-", "+", "(", ")")
                            CalcKey(
                                label = key,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(58.dp)
                                    .testTag("calc_key_$key"),
                                isAccent = isRedEqual,
                                isAction = isAction,
                                onClick = { onKeyClick(key) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Calculation History Bottom Sheet
    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CALCULATION HISTORY",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        fontFamily = SpaceGroteskFontFamily
                    )
                    Surface(
                        onClick = {
                            HapticHelper.performClick(context, hapticEnabled)
                            viewModel.clearCalculatorHistory()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = NothingRed.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = "Clear",
                            color = NothingRed,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (calcHistory.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No calculations yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth().height(300.dp)
                    ) {
                        items(calcHistory) { item ->
                            Surface(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    expression = item.expression
                                    resultText = item.result
                                    showHistorySheet = false
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = item.expression,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "= ${item.result}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = NothingRed
                                        )
                                    }
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalcKey(
    label: String,
    modifier: Modifier = Modifier,
    isAccent: Boolean = false,
    isAction: Boolean = false,
    isSpecial: Boolean = false,
    onClick: () -> Unit
) {
    val bgColor = when {
        isAccent -> NothingRed
        isSpecial -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        isAction -> MaterialTheme.colorScheme.surfaceVariant
        else -> MaterialTheme.colorScheme.surface
    }

    val contentColor = when {
        isAccent -> Color.White
        isAction -> if (label == "AC") NothingRed else MaterialTheme.colorScheme.onSurface
        else -> MaterialTheme.colorScheme.onSurface
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isAccent) 0f else 0.4f)),
        modifier = modifier
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = if (isSpecial) MaterialTheme.typography.labelMedium else MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontFamily = SpaceGroteskFontFamily,
                color = contentColor
            )
        }
    }
}
