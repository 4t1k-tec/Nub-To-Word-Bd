package com.example.ui.pdf

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.NothingCard
import com.example.ui.components.NothingSectionHeader
import com.example.ui.theme.NothingRed
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.util.HapticHelper
import com.example.util.ImageProcessingHelper
import com.example.util.PageOrientation
import com.example.util.PdfCreatorHelper
import com.example.util.PdfPageItem
import com.example.util.ScaleMode
import com.example.util.ShareHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfCreatorScreen(
    viewModel: MainViewModel,
    initialPdfPath: String? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val appSettings by viewModel.appSettings.collectAsState()
    val isBangla = appSettings.language == "bn"
    val hapticEnabled = appSettings.hapticEnabled

    var documentName by remember { mutableStateOf("BDT_Document_${System.currentTimeMillis() % 100000}") }
    var orientation by remember { mutableStateOf(PageOrientation.PORTRAIT) }
    var scaleMode by remember { mutableStateOf(ScaleMode.FIT_PAGE) }
    var marginPt by remember { mutableFloatStateOf(20f) }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedFile by remember { mutableStateOf<File?>(null) }

    val pageList = remember { mutableStateListOf<PdfPageItem>() }
    var selectedPageIndex by remember { mutableIntStateOf(0) }

    // Import images from gallery
    val galleryPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                isGenerating = true
                for (uri in uris) {
                    val bmp = ImageProcessingHelper.loadBitmapFromUri(context, uri)
                    if (bmp != null) {
                        val file = ImageProcessingHelper.saveBitmapToFile(context, bmp, "pdf_page")
                        pageList.add(PdfPageItem(imagePath = file.absolutePath))
                    }
                }
                isGenerating = false
            }
        }
    }

    LaunchedEffect(initialPdfPath) {
        if (!initialPdfPath.isNullOrEmpty()) {
            val f = File(initialPdfPath)
            if (f.exists()) {
                generatedFile = f
                documentName = f.nameWithoutExtension
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(NothingRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBangla) "A4 পিডিএফ ক্রিয়েটর" else "A4 PDF CREATOR",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            HapticHelper.performClick(context, hapticEnabled)
                            onBack()
                        },
                        modifier = Modifier.testTag("pdf_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (generatedFile != null) {
                        IconButton(
                            onClick = {
                                HapticHelper.performClick(context, hapticEnabled)
                                ShareHelper.shareFile(context, generatedFile!!, "application/pdf")
                            },
                            modifier = Modifier.testTag("pdf_share_top_btn")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share PDF", tint = NothingRed)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("pdf_creator_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Document Name & A4 Specs Card
            item {
                NothingCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "A4 SPECIFICATION",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = NothingRed.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "210 × 297 mm",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = NothingRed,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = documentName,
                            onValueChange = { documentName = it },
                            label = { Text("Document File Name") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pdf_name_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NothingRed,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                    }
                }
            }

            // Orientation & Scaling Card
            item {
                NothingCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "PAGE ORIENTATION",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    orientation = PageOrientation.PORTRAIT
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (orientation == PageOrientation.PORTRAIT) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Portrait (লম্বালম্বি)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (orientation == PageOrientation.PORTRAIT) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Surface(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    orientation = PageOrientation.LANDSCAPE
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = if (orientation == PageOrientation.LANDSCAPE) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Landscape (আড়াআড়ি)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (orientation == PageOrientation.LANDSCAPE) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "IMAGE SCALING MODE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ScaleMode.values().forEach { mode ->
                                val isSelected = scaleMode == mode
                                Surface(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        scaleMode = mode
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) NothingRed else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                                    modifier = Modifier.weight(1f).height(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = when (mode) {
                                                ScaleMode.FIT_PAGE -> "Fit Page"
                                                ScaleMode.FILL_PAGE -> "Fill Page"
                                                ScaleMode.PRESERVE_ASPECT -> "Aspect"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "MARGIN: ${marginPt.toInt()} pt",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Slider(
                            value = marginPt,
                            onValueChange = { marginPt = it },
                            valueRange = 0f..60f,
                            colors = SliderDefaults.colors(
                                thumbColor = NothingRed,
                                activeTrackColor = NothingRed
                            )
                        )
                    }
                }
            }

            // Pages Management Section
            item {
                NothingSectionHeader(
                    title = "DOCUMENT PAGES (${pageList.size})",
                    action = {
                        Surface(
                            onClick = {
                                HapticHelper.performClick(context, hapticEnabled)
                                galleryPicker.launch("image/*")
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Images", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                )
            }

            if (pageList.isEmpty()) {
                item {
                    NothingCard {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No pages added yet", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            Text(
                                "Add pages from camera or gallery to build an A4 PDF document",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                itemsIndexed(pageList) { index, item ->
                    val isSelected = selectedPageIndex == index
                    NothingCard(
                        onClick = {
                            HapticHelper.performClick(context, hapticEnabled)
                            selectedPageIndex = index
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(NothingRed.copy(alpha = 0.15f), RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NothingRed
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Page ${index + 1}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Rotation: ${item.rotationDegrees.toInt()}°",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Reorder and rotate controls
                            IconButton(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    val newRot = (item.rotationDegrees + 90f) % 360f
                                    pageList[index] = item.copy(rotationDegrees = newRot)
                                }
                            ) {
                                Icon(Icons.Default.RotateRight, contentDescription = "Rotate", modifier = Modifier.size(20.dp))
                            }

                            if (index > 0) {
                                IconButton(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        val temp = pageList[index]
                                        pageList[index] = pageList[index - 1]
                                        pageList[index - 1] = temp
                                    }
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(20.dp))
                                }
                            }

                            if (index < pageList.size - 1) {
                                IconButton(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        val temp = pageList[index]
                                        pageList[index] = pageList[index + 1]
                                        pageList[index + 1] = temp
                                    }
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(20.dp))
                                }
                            }

                            IconButton(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    pageList.removeAt(index)
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Page", tint = NothingRed, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }

            // Export Button
            item {
                Surface(
                    onClick = {
                        if (pageList.isEmpty()) {
                            Toast.makeText(context, "Please add at least one page", Toast.LENGTH_SHORT).show()
                            return@Surface
                        }
                        HapticHelper.performHeavyClick(context, hapticEnabled)
                        scope.launch {
                            isGenerating = true
                            val resultFile = PdfCreatorHelper.createA4Pdf(
                                context = context,
                                pages = pageList.toList(),
                                fileName = documentName,
                                orientation = orientation,
                                scaleMode = scaleMode,
                                marginPt = marginPt
                            )
                            viewModel.registerCreatedDocument(resultFile, "application/pdf", pageList.size)
                            generatedFile = resultFile
                            isGenerating = false
                            Toast.makeText(context, "A4 PDF exported successfully", Toast.LENGTH_SHORT).show()
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = if (pageList.isNotEmpty()) NothingRed else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("pdf_export_btn")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isGenerating) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "EXPORT A4 PDF DOCUMENT",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Generated PDF Success & Direct Share Actions
            generatedFile?.let { file ->
                item {
                    NothingCard(hasRedDot = true) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            Text(
                                text = "PDF READY FOR SHARING",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = NothingRed
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = file.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Size: ${file.length() / 1024} KB • A4 Standard",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        ShareHelper.shareFile(context, file, "application/pdf", targetWhatsAppOnly = true)
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Text("WhatsApp", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Surface(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        ShareHelper.shareFile(context, file, "application/pdf")
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f).height(44.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Text("Share Native", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.surface)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
