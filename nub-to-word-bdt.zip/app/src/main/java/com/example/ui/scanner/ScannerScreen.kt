package com.example.ui.scanner

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.NothingCard
import com.example.ui.theme.NothingRed
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.util.EnhancementMode
import com.example.util.HapticHelper
import com.example.util.ImageProcessingHelper
import com.example.util.PdfCreatorHelper
import com.example.util.PdfPageItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

data class ScannedPage(
    val file: File,
    var rotation: Float = 0f,
    var enhancementMode: EnhancementMode = EnhancementMode.DOCUMENT_CLARITY,
    var brightness: Float = 0f,
    var contrast: Float = 1.0f
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToPdf: (String?) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val appSettings by viewModel.appSettings.collectAsState()
    val isBangla = appSettings.language == "bn"
    val hapticEnabled = appSettings.hapticEnabled

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    // Scanned Pages list
    val pages = remember { mutableStateListOf<ScannedPage>() }
    var selectedPageIndex by remember { mutableIntStateOf(0) }
    var isLiveCameraActive by remember { mutableStateOf(true) }
    var previewProcessedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isProcessing by remember { mutableStateOf(false) }

    // Adjustment sliders for selected page
    var currentFilter by remember { mutableStateOf(EnhancementMode.DOCUMENT_CLARITY) }
    var brightnessSlider by remember { mutableFloatStateOf(0f) }
    var contrastSlider by remember { mutableFloatStateOf(1.0f) }
    var currentRotation by remember { mutableFloatStateOf(0f) }

    // Image capture instance
    val imageCapture = remember { ImageCapture.Builder().build() }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    // Photo picker for importing from gallery
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                isProcessing = true
                for (uri in uris) {
                    val bmp = ImageProcessingHelper.loadBitmapFromUri(context, uri)
                    if (bmp != null) {
                        val savedFile = ImageProcessingHelper.saveBitmapToFile(context, bmp, "import")
                        pages.add(ScannedPage(file = savedFile))
                    }
                }
                if (pages.isNotEmpty()) {
                    isLiveCameraActive = false
                    selectedPageIndex = pages.size - 1
                }
                isProcessing = false
            }
        }
    }

    // Update preview when adjustments change
    LaunchedEffect(selectedPageIndex, currentFilter, brightnessSlider, contrastSlider, currentRotation, pages.size) {
        if (!isLiveCameraActive && pages.isNotEmpty() && selectedPageIndex in pages.indices) {
            val page = pages[selectedPageIndex]
            scope.launch(Dispatchers.Default) {
                val raw = ImageProcessingHelper.loadBitmapFromFile(page.file.absolutePath)
                if (raw != null) {
                    val processed = ImageProcessingHelper.applyEnhancements(
                        src = raw,
                        mode = currentFilter,
                        brightness = brightnessSlider,
                        contrast = contrastSlider,
                        rotationDegrees = currentRotation
                    )
                    withContext(Dispatchers.Main) {
                        previewProcessedBitmap = processed
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(NothingRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBangla) "ডকুমেন্ট স্ক্যানার" else "DOCUMENT SCANNER",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            HapticHelper.performClick(context, hapticEnabled)
                            onBack()
                        },
                        modifier = Modifier.testTag("scanner_back_btn")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (pages.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                HapticHelper.performHeavyClick(context, hapticEnabled)
                                // Export as A4 PDF and save
                                scope.launch {
                                    isProcessing = true
                                    val pdfItems = pages.map { page ->
                                        PdfPageItem(
                                            imagePath = page.file.absolutePath,
                                            rotationDegrees = page.rotation
                                        )
                                    }
                                    val pdfFile = PdfCreatorHelper.createA4Pdf(
                                        context = context,
                                        pages = pdfItems,
                                        fileName = "Scanned_Document_${System.currentTimeMillis()}"
                                    )
                                    viewModel.registerCreatedDocument(pdfFile, "application/pdf", pages.size)
                                    isProcessing = false
                                    Toast.makeText(context, R.string.pdf_exported_success, Toast.LENGTH_SHORT).show()
                                    onNavigateToPdf(pdfFile.absolutePath)
                                }
                            },
                            modifier = Modifier.testTag("scanner_export_pdf_btn")
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "Create PDF", tint = NothingRed)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Main View Area: Either Live Camera or Processed Page Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (isLiveCameraActive) {
                    if (hasCameraPermission) {
                        AndroidView(
                            factory = { ctx ->
                                val previewView = PreviewView(ctx)
                                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                cameraProviderFuture.addListener({
                                    val cameraProvider = cameraProviderFuture.get()
                                    val preview = Preview.Builder().build().also {
                                        it.surfaceProvider = previewView.surfaceProvider
                                    }
                                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                    try {
                                        cameraProvider.unbindAll()
                                        cameraProvider.bindToLifecycle(
                                            lifecycleOwner,
                                            cameraSelector,
                                            preview,
                                            imageCapture
                                        )
                                    } catch (e: Exception) {
                                        // Ignore
                                    }
                                }, ContextCompat.getMainExecutor(ctx))
                                previewView
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        // Viewfinder Overlay (Nothing OS style dotted corners)
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .aspectRatio(1f / 1.414f) // A4 ratio viewfinder
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Transparent)
                            )
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.camera_permission_required),
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Surface(
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                shape = RoundedCornerShape(12.dp),
                                color = NothingRed
                            ) {
                                Text(
                                    text = stringResource(R.string.grant_permission),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                } else {
                    // Page Preview
                    previewProcessedBitmap?.let { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Scan Preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } ?: CircularProgressIndicator(color = NothingRed)
                }

                if (isProcessing) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = NothingRed)
                    }
                }
            }

            // Scanned Pages Tray (Thumbnail Bar)
            if (pages.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${pages.size} ${if (isBangla) "পৃষ্ঠা" else "Page(s)"}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = NothingRed
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            itemsIndexed(pages) { index, page ->
                                val isSelected = !isLiveCameraActive && selectedPageIndex == index
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) NothingRed else MaterialTheme.colorScheme.surface)
                                        .clickable {
                                            HapticHelper.performClick(context, hapticEnabled)
                                            isLiveCameraActive = false
                                            selectedPageIndex = index
                                            currentFilter = page.enhancementMode
                                            currentRotation = page.rotation
                                            brightnessSlider = page.brightness
                                            contrastSlider = page.contrast
                                        }
                                        .padding(2.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "P${index + 1}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        // Add page / switch back to live camera
                        IconButton(
                            onClick = {
                                HapticHelper.performClick(context, hapticEnabled)
                                isLiveCameraActive = true
                            }
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Page")
                        }
                    }
                }
            }

            // Controls Panel (Filters & Adjustments when previewing page, or Capture buttons when live camera)
            Surface(
                color = MaterialTheme.colorScheme.background,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (isLiveCameraActive) {
                        // Live Camera Bottom Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Gallery Import Button
                            Surface(
                                onClick = {
                                    HapticHelper.performClick(context, hapticEnabled)
                                    galleryLauncher.launch("image/*")
                                },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .size(54.dp)
                                    .testTag("scanner_gallery_btn")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery")
                                }
                            }

                            // Big Capture Shutter Button (Nothing inspired red ring)
                            Surface(
                                onClick = {
                                    HapticHelper.performHeavyClick(context, hapticEnabled)
                                    isProcessing = true
                                    val photoFile = File(context.filesDir, "scan_${System.currentTimeMillis()}.jpg")
                                    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

                                    imageCapture.takePicture(
                                        outputOptions,
                                        cameraExecutor,
                                        object : ImageCapture.OnImageSavedCallback {
                                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                scope.launch(Dispatchers.Main) {
                                                    pages.add(ScannedPage(file = photoFile))
                                                    selectedPageIndex = pages.size - 1
                                                    isLiveCameraActive = false
                                                    isProcessing = false
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                scope.launch(Dispatchers.Main) {
                                                    isProcessing = false
                                                    Toast.makeText(context, "Capture failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    )
                                },
                                shape = CircleShape,
                                color = NothingRed,
                                border = BorderStroke(4.dp, MaterialTheme.colorScheme.onSurface),
                                modifier = Modifier
                                    .size(76.dp)
                                    .testTag("scanner_shutter_btn")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.CameraAlt,
                                        contentDescription = "Capture",
                                        tint = Color.White,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                            }

                            // View captured pages / toggle preview
                            Surface(
                                onClick = {
                                    if (pages.isNotEmpty()) {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        isLiveCameraActive = false
                                        selectedPageIndex = 0
                                    }
                                },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.size(54.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Done Scanning",
                                        tint = if (pages.isNotEmpty()) NothingRed else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        // Image Enhancement Modes (Horizontal Chips)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            EnhancementMode.values().forEach { mode ->
                                val isSelected = currentFilter == mode
                                Surface(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        currentFilter = mode
                                        if (selectedPageIndex in pages.indices) {
                                            pages[selectedPageIndex].enhancementMode = mode
                                        }
                                    },
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, if (isSelected) NothingRed else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                                ) {
                                    Text(
                                        text = mode.name.replace("_", " "),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Actions: Rotate, Reset, Delete Page
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        currentRotation = (currentRotation + 90f) % 360f
                                        if (selectedPageIndex in pages.indices) {
                                            pages[selectedPageIndex].rotation = currentRotation
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.RotateRight, contentDescription = "Rotate")
                                }

                                IconButton(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        currentFilter = EnhancementMode.DOCUMENT_CLARITY
                                        brightnessSlider = 0f
                                        contrastSlider = 1.0f
                                        currentRotation = 0f
                                    }
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Reset")
                                }
                            }

                            if (pages.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        HapticHelper.performClick(context, hapticEnabled)
                                        if (selectedPageIndex in pages.indices) {
                                            pages.removeAt(selectedPageIndex)
                                            if (pages.isEmpty()) {
                                                isLiveCameraActive = true
                                            } else {
                                                selectedPageIndex = (selectedPageIndex - 1).coerceAtLeast(0)
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Page", tint = NothingRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
