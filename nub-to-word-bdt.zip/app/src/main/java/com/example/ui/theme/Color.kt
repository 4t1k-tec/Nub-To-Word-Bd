package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nothing-Inspired Monochrome & Restrained Red Palette
val NothingRed = Color(0xFFD71920)
val NothingRedDark = Color(0xFFB5141A)
val NothingRedLight = Color(0xFFFF3B30)

// Light Theme
val NothingWhite = Color(0xFFFFFFFF)
val NothingLightGrey = Color(0xFFF2F4F7)
val NothingLightCard = Color(0xFFFFFFFF)
val NothingLightBorder = Color(0xFFE2E4E8)
val NothingBlack = Color(0xFF111111)
val NothingGreyText = Color(0xFF6E7178)
val NothingSubtleGrey = Color(0xFF9EA3AE)

// AMOLED Dark Theme
val NothingAmoledBlack = Color(0xFF000000)
val NothingDarkSurface = Color(0xFF121212)
val NothingDarkCard = Color(0xFF18181A)
val NothingDarkBorder = Color(0xFF28282C)
val NothingDarkTextPrimary = Color(0xFFF5F5F7)
val NothingDarkTextSecondary = Color(0xFF8E8E93)
val NothingDarkSubtle = Color(0xFF38383E)
