package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NothingRed,
    onPrimary = NothingWhite,
    primaryContainer = NothingDarkCard,
    onPrimaryContainer = NothingDarkTextPrimary,
    secondary = NothingWhite,
    onSecondary = NothingAmoledBlack,
    secondaryContainer = NothingDarkSurface,
    onSecondaryContainer = NothingDarkTextPrimary,
    background = NothingAmoledBlack,
    onBackground = NothingDarkTextPrimary,
    surface = NothingDarkSurface,
    onSurface = NothingDarkTextPrimary,
    surfaceVariant = NothingDarkCard,
    onSurfaceVariant = NothingDarkTextSecondary,
    outline = NothingDarkBorder,
    error = NothingRed,
    onError = NothingWhite
)

private val LightColorScheme = lightColorScheme(
    primary = NothingRed,
    onPrimary = NothingWhite,
    primaryContainer = NothingLightGrey,
    onPrimaryContainer = NothingBlack,
    secondary = NothingBlack,
    onSecondary = NothingWhite,
    secondaryContainer = NothingLightCard,
    onSecondaryContainer = NothingBlack,
    background = NothingWhite,
    onBackground = NothingBlack,
    surface = NothingWhite,
    onSurface = NothingBlack,
    surfaceVariant = NothingLightGrey,
    onSurfaceVariant = NothingGreyText,
    outline = NothingLightBorder,
    error = NothingRed,
    onError = NothingWhite
)

@Composable
fun NubToWordBDTTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
