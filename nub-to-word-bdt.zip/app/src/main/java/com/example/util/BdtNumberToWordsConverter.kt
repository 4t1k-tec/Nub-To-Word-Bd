package com.example.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Precision South Asian (Bangladeshi Taka - BDT) Number to Words Converter.
 * Accurately handles:
 * - Bangladeshi comma grouping (1,23,45,678)
 * - Digits: English (0-9) and Bengali (০-৯)
 * - Lakhs (লক্ষ) and Crores (কোটি) hierarchy
 * - Decimals (Poisha / পয়সা)
 * - Grammatically correct Bengali (বাংলা) words from 0 to 99
 * - Zero and negative amounts
 * - Configurable suffixes ("Taka Only", "Taka and Poisha Only")
 */
object BdtNumberToWordsConverter {

    private val ENGLISH_UNITS = arrayOf(
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
        "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
        "Seventeen", "Eighteen", "Nineteen"
    )

    private val ENGLISH_TENS = arrayOf(
        "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    )

    // Complete standard linguistic Bengali words for 0 to 99
    private val BANGLA_WORDS_0_TO_99 = arrayOf(
        "শূন্য", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ",
        "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "উনিশ", "বিশ",
        "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আটাশ", "ঊনত্রিশ", "ত্রিশ",
        "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁয়ত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ", "চল্লিশ",
        "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁয়তাল্লিশ", "ছেচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ", "পঞ্চাশ",
        "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট", "ষাট",
        "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁয়ষট্টি", "ছেষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর", "সত্তর",
        "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি", "আশি",
        "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাসি", "আটাশি", "ঊননব্বই", "নব্বই",
        "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই"
    )

    private val BN_DIGITS = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    /**
     * Converts any string containing Bengali or English digits into standard English digits.
     */
    fun toEnglishDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            when (ch) {
                '০' -> sb.append('0')
                '১' -> sb.append('1')
                '২' -> sb.append('2')
                '৩' -> sb.append('3')
                '৪' -> sb.append('4')
                '৫' -> sb.append('5')
                '৬' -> sb.append('6')
                '৭' -> sb.append('7')
                '৮' -> sb.append('8')
                '৯' -> sb.append('9')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Converts English digits in a string to Bengali numerals.
     */
    fun toBengaliDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(BN_DIGITS[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Formats an amount using the Bangladeshi comma grouping system:
     * Last 3 digits, then groups of 2 digits (e.g., 1,23,45,678.50).
     */
    fun formatBdtGrouping(rawInput: String, useBengaliDigits: Boolean = false): String {
        val cleaned = toEnglishDigits(rawInput.trim()).replace(",", "")
        if (cleaned.isEmpty()) return ""

        val isNegative = cleaned.startsWith("-")
        val numStr = if (isNegative) cleaned.substring(1) else cleaned

        val parts = numStr.split(".")
        val integerPart = parts[0].trimStart('0').ifEmpty { "0" }
        val decimalPart = if (parts.size > 1) "." + parts[1].take(2) else ""

        val formattedInt = applySouthAsianCommas(integerPart)
        val result = (if (isNegative) "-" else "") + formattedInt + decimalPart
        return if (useBengaliDigits) toBengaliDigits(result) else result
    }

    private fun applySouthAsianCommas(intStr: String): String {
        val len = intStr.length
        if (len <= 3) return intStr

        val last3 = intStr.substring(len - 3)
        var remaining = intStr.substring(0, len - 3)
        val groups = mutableListOf<String>()

        while (remaining.length > 2) {
            groups.add(0, remaining.substring(remaining.length - 2))
            remaining = remaining.substring(0, remaining.length - 2)
        }
        if (remaining.isNotEmpty()) {
            groups.add(0, remaining)
        }

        return groups.joinToString(",") + "," + last3
    }

    data class ConversionResult(
        val rawInput: String,
        val formattedAmount: String,
        val englishWords: String,
        val banglaWords: String,
        val crore: Long = 0,
        val lakh: Long = 0,
        val thousand: Long = 0,
        val hundred: Long = 0,
        val remainingTaka: Long = 0,
        val poisha: Long = 0,
        val isNegative: Boolean = false,
        val isValid: Boolean = true,
        val errorMessage: String? = null
    )

    /**
     * Converts a raw input number into English and Bangla words.
     */
    fun convert(
        input: String,
        includePoishaWords: Boolean = true,
        takaOnlySuffix: Boolean = true
    ): ConversionResult {
        val sanitized = toEnglishDigits(input.trim()).replace(",", "").replace(" ", "")
        if (sanitized.isEmpty()) {
            return ConversionResult(
                rawInput = input,
                formattedAmount = "",
                englishWords = "",
                banglaWords = "",
                isValid = false,
                errorMessage = "Please enter an amount"
            )
        }

        val isNegative = sanitized.startsWith("-")
        val positiveStr = if (isNegative) sanitized.substring(1) else sanitized

        val parts = positiveStr.split(".")
        if (parts.size > 2) {
            return ConversionResult(
                rawInput = input,
                formattedAmount = input,
                englishWords = "Invalid format",
                banglaWords = "ভুল ফরম্যাট",
                isValid = false,
                errorMessage = "Invalid number format"
            )
        }

        val integerPartStr = parts[0].ifEmpty { "0" }
        val decimalPartStr = if (parts.size > 1) parts[1].padEnd(2, '0').take(2) else "00"

        val takaVal: Long
        val poishaVal: Long
        try {
            takaVal = integerPartStr.toLong()
            poishaVal = decimalPartStr.take(2).toLong()
        } catch (e: Exception) {
            return ConversionResult(
                rawInput = input,
                formattedAmount = input,
                englishWords = "Amount too large",
                banglaWords = "সংখ্যাটি অনেক বড়",
                isValid = false,
                errorMessage = "Amount exceeds supported limit"
            )
        }

        // Breakdown calculation
        var temp = takaVal
        val crore = temp / 10_000_000L
        temp %= 10_000_000L
        val lakh = temp / 100_000L
        temp %= 100_000L
        val thousand = temp / 1_000L
        temp %= 1_000L
        val hundred = temp / 100L
        val remainingTaka = temp % 100L

        val formattedAmount = (if (isNegative) "-" else "") +
                applySouthAsianCommas(takaVal.toString()) +
                (if (poishaVal > 0) "." + decimalPartStr.take(2) else "")

        val enWords = buildEnglishWords(takaVal, poishaVal, isNegative, includePoishaWords, takaOnlySuffix)
        val bnWords = buildBanglaWords(takaVal, poishaVal, isNegative, includePoishaWords)

        return ConversionResult(
            rawInput = input,
            formattedAmount = formattedAmount,
            englishWords = enWords,
            banglaWords = bnWords,
            crore = crore,
            lakh = lakh,
            thousand = thousand,
            hundred = hundred,
            remainingTaka = remainingTaka,
            poisha = poishaVal,
            isNegative = isNegative,
            isValid = true
        )
    }

    // ----------------- English Conversion -----------------
    private fun buildEnglishWords(
        taka: Long,
        poisha: Long,
        isNegative: Boolean,
        includePoishaWords: Boolean,
        takaOnlySuffix: Boolean
    ): String {
        val prefix = if (isNegative) "Minus " else ""

        if (taka == 0L && (poisha == 0L || !includePoishaWords)) {
            return "Zero Taka Only."
        }

        val takaWords = if (taka > 0L) convertTakaToEnglishWords(taka) else ""
        val poishaWords = if (includePoishaWords && poisha > 0L) convertTakaToEnglishWords(poisha) else ""

        val result = StringBuilder(prefix)
        if (takaWords.isNotEmpty()) {
            result.append(takaWords).append(" Taka")
        }

        if (poishaWords.isNotEmpty()) {
            if (takaWords.isNotEmpty()) {
                result.append(" and ")
            }
            result.append(poishaWords).append(" Poisha")
        }

        if (takaOnlySuffix) {
            result.append(" Only.")
        } else {
            result.append(".")
        }

        return result.toString().trim()
    }

    private fun convertTakaToEnglishWords(n: Long): String {
        if (n == 0L) return ""
        val sb = StringBuilder()

        val crore = n / 10_000_000L
        val remCrore = n % 10_000_000L

        if (crore > 0) {
            sb.append(convertTakaToEnglishWords(crore)).append(" Crore ")
        }

        val lakh = remCrore / 100_000L
        val remLakh = remCrore % 100_000L
        if (lakh > 0) {
            sb.append(convertUnderHundredEnglish(lakh.toInt())).append(" Lakh ")
        }

        val thousand = remLakh / 1_000L
        val remThousand = remLakh % 1_000L
        if (thousand > 0) {
            sb.append(convertUnderHundredEnglish(thousand.toInt())).append(" Thousand ")
        }

        val hundred = remThousand / 100L
        val rest = remThousand % 100L
        if (hundred > 0) {
            sb.append(ENGLISH_UNITS[hundred.toInt()]).append(" Hundred ")
        }

        if (rest > 0) {
            sb.append(convertUnderHundredEnglish(rest.toInt())).append(" ")
        }

        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    private fun convertUnderHundredEnglish(num: Int): String {
        return if (num < 20) {
            ENGLISH_UNITS[num]
        } else {
            val tens = ENGLISH_TENS[num / 10]
            val units = ENGLISH_UNITS[num % 10]
            if (units.isNotEmpty()) "$tens-$units" else tens
        }
    }

    // ----------------- Bangla Conversion -----------------
    private fun buildBanglaWords(
        taka: Long,
        poisha: Long,
        isNegative: Boolean,
        includePoisha: Boolean
    ): String {
        val prefix = if (isNegative) "মাইনাস " else ""

        if (taka == 0L && (poisha == 0L || !includePoisha)) {
            return "শূন্য টাকা মাত্র।"
        }

        val takaWords = if (taka > 0L) convertTakaToBanglaWords(taka) else ""
        val poishaWords = if (includePoisha && poisha > 0L) convertUnderHundredBangla(poisha.toInt()) else ""

        val result = StringBuilder(prefix)
        if (takaWords.isNotEmpty()) {
            result.append(takaWords).append(" টাকা")
        }

        if (poishaWords.isNotEmpty()) {
            if (takaWords.isNotEmpty()) {
                result.append(" ও ")
            }
            result.append(poishaWords).append(" পয়সা")
        }

        result.append(" মাত্র।")
        return result.toString().trim().replace(Regex("\\s+"), " ")
    }

    private fun convertTakaToBanglaWords(n: Long): String {
        if (n == 0L) return ""
        val sb = StringBuilder()

        val crore = n / 10_000_000L
        val remCrore = n % 10_000_000L

        if (crore > 0) {
            sb.append(convertTakaToBanglaWords(crore)).append(" কোটি ")
        }

        val lakh = remCrore / 100_000L
        val remLakh = remCrore % 100_000L
        if (lakh > 0) {
            sb.append(convertUnderHundredBangla(lakh.toInt())).append(" লক্ষ ")
        }

        val thousand = remLakh / 1_000L
        val remThousand = remLakh % 1_000L
        if (thousand > 0) {
            sb.append(convertUnderHundredBangla(thousand.toInt())).append(" হাজার ")
        }

        val hundred = remThousand / 100L
        val rest = remThousand % 100L
        if (hundred > 0) {
            if (hundred == 1L) {
                sb.append("একশ ")
            } else {
                sb.append(convertUnderHundredBangla(hundred.toInt())).append(" শত ")
            }
        }

        if (rest > 0) {
            sb.append(convertUnderHundredBangla(rest.toInt())).append(" ")
        }

        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    private fun convertUnderHundredBangla(num: Int): String {
        return if (num in 0..99) {
            BANGLA_WORDS_0_TO_99[num]
        } else {
            ""
        }
    }
}
