package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Bangladesh Standard Time (BST, Asia/Dhaka UTC+06:00) helper.
 * Formats live clock and calendar dates in English and Bengali.
 */
object BdtTimeHelper {

    val DHAKA_ZONE: TimeZone = TimeZone.getTimeZone("Asia/Dhaka")

    private val BANGLA_MONTHS = arrayOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    private val BANGLA_DAYS = arrayOf(
        "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
    )

    data class FormattedDateTime(
        val timeEnglish: String,       // e.g. "01:45:22 PM"
        val timeShortEnglish: String,  // e.g. "01:45 PM"
        val dateEnglish: String,       // e.g. "Wednesday, 21 Oct 2026"
        val timeBangla: String,        // e.g. "০১:৪৫ অপরাহ্ন"
        val dateBangla: String,        // e.g. "বুধবার, ২১ অক্টোবর ২০২৬"
        val timeZoneLabel: String = "BST (UTC+6)"
    )

    fun getCurrentBdtDateTime(): FormattedDateTime {
        val now = Date()
        val cal = Calendar.getInstance(DHAKA_ZONE)
        cal.time = now

        // 12-hour time formatter for English
        val timeFormat = SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH).apply {
            timeZone = DHAKA_ZONE
        }
        val shortTimeFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH).apply {
            timeZone = DHAKA_ZONE
        }
        val dateFormat = SimpleDateFormat("EEEE, dd MMM yyyy", Locale.ENGLISH).apply {
            timeZone = DHAKA_ZONE
        }

        val timeEn = timeFormat.format(now)
        val shortTimeEn = shortTimeFormat.format(now)
        val dateEn = dateFormat.format(now)

        // Bangla components
        val hour12 = cal.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val minute = cal.get(Calendar.MINUTE)
        val isAm = cal.get(Calendar.AM_PM) == Calendar.AM

        val hourStr = BdtNumberToWordsConverter.toBengaliDigits(String.format(Locale.ROOT, "%02d", hour12))
        val minStr = BdtNumberToWordsConverter.toBengaliDigits(String.format(Locale.ROOT, "%02d", minute))
        val amPmBn = if (isAm) "পূর্বাহ্ন" else "অপরাহ্ন"
        val timeBn = "$hourStr:$minStr $amPmBn"

        val dayOfWeekIndex = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sunday
        val dayNameBn = BANGLA_DAYS.getOrElse(dayOfWeekIndex) { "" }
        val dayOfMonthBn = BdtNumberToWordsConverter.toBengaliDigits(cal.get(Calendar.DAY_OF_MONTH).toString())
        val monthIndex = cal.get(Calendar.MONTH)
        val monthNameBn = BANGLA_MONTHS.getOrElse(monthIndex) { "" }
        val yearBn = BdtNumberToWordsConverter.toBengaliDigits(cal.get(Calendar.YEAR).toString())
        val dateBn = "$dayNameBn, $dayOfMonthBn $monthNameBn $yearBn"

        return FormattedDateTime(
            timeEnglish = timeEn,
            timeShortEnglish = shortTimeEn,
            dateEnglish = dateEn,
            timeBangla = timeBn,
            dateBangla = dateBn
        )
    }
}
