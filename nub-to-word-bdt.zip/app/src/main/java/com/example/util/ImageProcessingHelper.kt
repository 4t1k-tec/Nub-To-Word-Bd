package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

enum class EnhancementMode {
    ORIGINAL,
    BW,
    GRAYSCALE,
    COLOR,
    ENHANCED_COLOR,
    DOCUMENT_CLARITY
}

object ImageProcessingHelper {

    suspend fun loadBitmapFromUri(context: Context, uri: Uri, maxDimension: Int = 1800): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeStream(stream, null, options)

                    val actualStream = context.contentResolver.openInputStream(uri)
                    val sampleSize = calculateInSampleSize(options, maxDimension, maxDimension)
                    val decodeOptions = BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                    BitmapFactory.decodeStream(actualStream, null, decodeOptions)
                }
            } catch (e: Exception) {
                null
            }
        }

    suspend fun loadBitmapFromFile(filePath: String, maxDimension: Int = 1800): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                val file = File(filePath)
                if (!file.exists()) return@withContext null
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(filePath, options)
                val sampleSize = calculateInSampleSize(options, maxDimension, maxDimension)
                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                BitmapFactory.decodeFile(filePath, decodeOptions)
            } catch (e: Exception) {
                null
            }
        }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    /**
     * Applies enhancement filter and custom brightness, contrast, and saturation adjustments.
     * Brightness: -100 to 100 (0 default)
     * Contrast: 0.5 to 2.0 (1.0 default)
     * Saturation: 0.0 to 2.0 (1.0 default)
     */
    fun applyEnhancements(
        src: Bitmap,
        mode: EnhancementMode,
        brightness: Float = 0f, // [-100, 100]
        contrast: Float = 1.0f,  // [0.5, 2.0]
        saturation: Float = 1.0f, // [0.0, 2.0]
        rotationDegrees: Float = 0f
    ): Bitmap {
        var baseBitmap = src
        if (rotationDegrees % 360f != 0f) {
            val matrix = Matrix().apply { postRotate(rotationDegrees) }
            baseBitmap = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
        }

        val result = Bitmap.createBitmap(baseBitmap.width, baseBitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val cm = ColorMatrix()

        when (mode) {
            EnhancementMode.ORIGINAL -> {
                // Identity
            }
            EnhancementMode.BW -> {
                // High contrast black & white
                cm.setSaturation(0f)
                val highContrast = floatArrayOf(
                    2.0f, 0f, 0f, 0f, -128f * 1.0f,
                    0f, 2.0f, 0f, 0f, -128f * 1.0f,
                    0f, 0f, 2.0f, 0f, -128f * 1.0f,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.postConcat(ColorMatrix(highContrast))
            }
            EnhancementMode.GRAYSCALE -> {
                cm.setSaturation(0f)
            }
            EnhancementMode.COLOR -> {
                // Clean standard color
            }
            EnhancementMode.ENHANCED_COLOR -> {
                cm.setSaturation(1.35f)
                val boost = floatArrayOf(
                    1.1f, 0f, 0f, 0f, 10f,
                    0f, 1.1f, 0f, 0f, 10f,
                    0f, 0f, 1.1f, 0f, 10f,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.postConcat(ColorMatrix(boost))
            }
            EnhancementMode.DOCUMENT_CLARITY -> {
                // Text whitening and high contrast for documents
                cm.setSaturation(0.2f)
                val clarityMatrix = floatArrayOf(
                    1.4f, 0f, 0f, 0f, -20f,
                    0f, 1.4f, 0f, 0f, -20f,
                    0f, 0f, 1.4f, 0f, -20f,
                    0f, 0f, 0f, 1f, 0f
                )
                cm.postConcat(ColorMatrix(clarityMatrix))
            }
        }

        // Apply custom sliders
        if (saturation != 1.0f && mode != EnhancementMode.BW && mode != EnhancementMode.GRAYSCALE) {
            val satMatrix = ColorMatrix()
            satMatrix.setSaturation(saturation)
            cm.postConcat(satMatrix)
        }

        if (contrast != 1.0f || brightness != 0f) {
            val scale = contrast
            val translate = (-0.5f * scale + 0.5f) * 255f + brightness
            val contrastMatrix = floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
            cm.postConcat(ColorMatrix(contrastMatrix))
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(baseBitmap, 0f, 0f, paint)

        return result
    }

    suspend fun saveBitmapToFile(context: Context, bitmap: Bitmap, prefix: String = "scan"): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.filesDir, "scans").apply { if (!exists()) mkdirs() }
            val file = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            file
        }
}
