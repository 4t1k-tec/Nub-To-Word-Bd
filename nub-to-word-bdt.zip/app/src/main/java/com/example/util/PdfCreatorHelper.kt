package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class PageOrientation {
    PORTRAIT,
    LANDSCAPE
}

enum class ScaleMode {
    FIT_PAGE,
    FILL_PAGE,
    PRESERVE_ASPECT
}

data class PdfPageItem(
    val imagePath: String,
    val rotationDegrees: Float = 0f
)

object PdfCreatorHelper {

    // Standard A4 dimensions in PostScript points (72 points per inch)
    // 210 mm = 8.27 in = 595 pt; 297 mm = 11.69 in = 842 pt
    const val A4_WIDTH_PT = 595
    const val A4_HEIGHT_PT = 842

    suspend fun createA4Pdf(
        context: Context,
        pages: List<PdfPageItem>,
        fileName: String,
        orientation: PageOrientation = PageOrientation.PORTRAIT,
        scaleMode: ScaleMode = ScaleMode.FIT_PAGE,
        marginPt: Float = 24f,
        qualityPercent: Int = 90
    ): File = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()

        val pageWidth = if (orientation == PageOrientation.PORTRAIT) A4_WIDTH_PT else A4_HEIGHT_PT
        val pageHeight = if (orientation == PageOrientation.PORTRAIT) A4_HEIGHT_PT else A4_WIDTH_PT

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        pages.forEachIndexed { index, pageItem ->
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
            val pdfPage = pdfDocument.startPage(pageInfo)
            val canvas: Canvas = pdfPage.canvas

            // Load and transform bitmap for this page
            val rawBitmap = ImageProcessingHelper.loadBitmapFromFile(pageItem.imagePath, maxDimension = 2000)
            if (rawBitmap != null) {
                var bitmap = rawBitmap
                if (pageItem.rotationDegrees % 360f != 0f) {
                    val rotMatrix = Matrix().apply { postRotate(pageItem.rotationDegrees) }
                    bitmap = Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, rotMatrix, true)
                }

                val availableWidth = pageWidth - (marginPt * 2)
                val availableHeight = pageHeight - (marginPt * 2)

                val bmpWidth = bitmap.width.toFloat()
                val bmpHeight = bitmap.height.toFloat()

                val matrix = Matrix()

                when (scaleMode) {
                    ScaleMode.FIT_PAGE, ScaleMode.PRESERVE_ASPECT -> {
                        val scale = (availableWidth / bmpWidth).coerceAtMost(availableHeight / bmpHeight)
                        val scaledW = bmpWidth * scale
                        val scaledH = bmpHeight * scale
                        val dx = marginPt + (availableWidth - scaledW) / 2f
                        val dy = marginPt + (availableHeight - scaledH) / 2f
                        matrix.postScale(scale, scale)
                        matrix.postTranslate(dx, dy)
                    }
                    ScaleMode.FILL_PAGE -> {
                        val scale = (availableWidth / bmpWidth).coerceAtLeast(availableHeight / bmpHeight)
                        val scaledW = bmpWidth * scale
                        val scaledH = bmpHeight * scale
                        val dx = marginPt + (availableWidth - scaledW) / 2f
                        val dy = marginPt + (availableHeight - scaledH) / 2f
                        matrix.postScale(scale, scale)
                        matrix.postTranslate(dx, dy)
                    }
                }

                canvas.drawBitmap(bitmap, matrix, paint)
                if (bitmap != rawBitmap) {
                    bitmap.recycle()
                }
                rawBitmap.recycle()
            }

            pdfDocument.finishPage(pdfPage)
        }

        val documentsDir = File(context.filesDir, "documents").apply { if (!exists()) mkdirs() }
        val cleanName = fileName.trim().ifEmpty { "BDT_Document_${System.currentTimeMillis()}" }
        val finalFileName = if (cleanName.endsWith(".pdf", ignoreCase = true)) cleanName else "$cleanName.pdf"
        val outFile = File(documentsDir, finalFileName)

        FileOutputStream(outFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        outFile
    }
}
