package com.example

import com.example.util.BdtNumberToWordsConverter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BdtConverterUnitTest {

    @Test
    fun testEnglishConversions() {
        assertEquals("Ten Taka Only.", BdtNumberToWordsConverter.convert("10").englishWords)
        assertEquals("One Hundred Taka Only.", BdtNumberToWordsConverter.convert("100").englishWords)
        assertEquals("One Thousand Taka Only.", BdtNumberToWordsConverter.convert("1000").englishWords)
        assertEquals("Ten Thousand Taka Only.", BdtNumberToWordsConverter.convert("10000").englishWords)
        assertEquals("One Lakh Taka Only.", BdtNumberToWordsConverter.convert("100000").englishWords)
        assertEquals("Ten Lakh Taka Only.", BdtNumberToWordsConverter.convert("1000000").englishWords)
        assertEquals("One Crore Taka Only.", BdtNumberToWordsConverter.convert("10000000").englishWords)
        assertEquals(
            "One Crore Twenty-Three Lakh Forty-Five Thousand Six Hundred Seventy-Eight Taka Only.",
            BdtNumberToWordsConverter.convert("12345678").englishWords
        )
    }

    @Test
    fun testBanglaConversions() {
        assertEquals("দশ টাকা মাত্র।", BdtNumberToWordsConverter.convert("১০").banglaWords)
        assertEquals("একশ টাকা মাত্র।", BdtNumberToWordsConverter.convert("১০০").banglaWords)
        assertEquals("এক হাজার টাকা মাত্র।", BdtNumberToWordsConverter.convert("১,০০০").banglaWords)
        assertEquals("দশ হাজার টাকা মাত্র।", BdtNumberToWordsConverter.convert("১০,০০০").banglaWords)
        assertEquals("এক লক্ষ টাকা মাত্র।", BdtNumberToWordsConverter.convert("১,০০,০০০").banglaWords)
        assertEquals("দশ লক্ষ টাকা মাত্র।", BdtNumberToWordsConverter.convert("১০,০০,০০০").banglaWords)
        assertEquals("এক কোটি টাকা মাত্র।", BdtNumberToWordsConverter.convert("১,০০,০০,০০০").banglaWords)
        assertEquals(
            "এক কোটি তেইশ লক্ষ পঁয়তাল্লিশ হাজার ছয় শত আটাত্তর টাকা মাত্র।",
            BdtNumberToWordsConverter.convert("১,২৩,৪৫,৬৭৮").banglaWords
        )
    }

    @Test
    fun testBangladeshiCommaGrouping() {
        assertEquals("1,23,45,678", BdtNumberToWordsConverter.formatBdtGrouping("12345678"))
        assertEquals("১০,০০,০০০", BdtNumberToWordsConverter.formatBdtGrouping("১০০০০০০", useBengaliDigits = true))
        assertEquals("1,00,00,000", BdtNumberToWordsConverter.formatBdtGrouping("10000000"))
        assertEquals("1,000", BdtNumberToWordsConverter.formatBdtGrouping("1000"))
        assertEquals("100", BdtNumberToWordsConverter.formatBdtGrouping("100"))
    }

    @Test
    fun testDecimalsAndPoisha() {
        val resultEn = BdtNumberToWordsConverter.convert("10.50")
        assertEquals("Ten Taka and Fifty Poisha Only.", resultEn.englishWords)
        assertEquals("দশ টাকা ও পঞ্চাশ পয়সা মাত্র।", resultEn.banglaWords)
        assertEquals(50L, resultEn.poisha)
    }

    @Test
    fun testZeroAndNegativeEdgeCases() {
        val zeroResult = BdtNumberToWordsConverter.convert("0")
        assertEquals("Zero Taka Only.", zeroResult.englishWords)
        assertEquals("শূন্য টাকা মাত্র।", zeroResult.banglaWords)

        val negativeResult = BdtNumberToWordsConverter.convert("-500")
        assertTrue(negativeResult.isNegative)
        assertEquals("Minus Five Hundred Taka Only.", negativeResult.englishWords)
        assertEquals("মাইনাস পাঁচ শত টাকা মাত্র।", negativeResult.banglaWords)
    }

    @Test
    fun testDigitConversionHelper() {
        assertEquals("1234567890", BdtNumberToWordsConverter.toEnglishDigits("১২৩৪৫৬৭৮৯০"))
        assertEquals("১২৩৪৫৬৭৮৯০", BdtNumberToWordsConverter.toBengaliDigits("1234567890"))
    }
}
